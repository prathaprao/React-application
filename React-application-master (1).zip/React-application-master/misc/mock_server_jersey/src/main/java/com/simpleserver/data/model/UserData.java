package com.simpleserver.data.model;

/**
 * @author sudhakar
 *
 */
public class UserData {
	
	int autoLeadId = 244944703;
	String CustomerName = "";
	    int year = 2016;
	    String make ;
	    String model ;
	    String trim ;
	    String leadSource ;
	    String leadStatus ;
	    String leadStatusType ;
	    String leadType ;
	    String groupCategory;
	    int globalCustomerId = 269677328;
	    String createdUtc = "2016-03-09T14:00:00";
	    String isHot;
	    String isOnShowroom; 
		double PredictionScore = 0.50;
		public int getAutoLeadId() {
			return autoLeadId;
		}
		public void setAutoLeadId(int autoLeadId) {
			this.autoLeadId = autoLeadId;
		}
		public String getCustomerName() {
			return CustomerName;
		}
		public void setCustomerName(String customerName) {
			CustomerName = customerName;
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public String getMake() {
			return make;
		}
		public void setMake(String make) {
			this.make = make;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public String getTrim() {
			return trim;
		}
		public void setTrim(String trim) {
			this.trim = trim;
		}
		public String getLeadSource() {
			return leadSource;
		}
		public void setLeadSource(String leadSource) {
			this.leadSource = leadSource;
		}
		public String getLeadStatus() {
			return leadStatus;
		}
		public void setLeadStatus(String leadStatus) {
			this.leadStatus = leadStatus;
		}
		public String getLeadStatusType() {
			return leadStatusType;
		}
		public void setLeadStatusType(String leadStatusType) {
			this.leadStatusType = leadStatusType;
		}
		public String getLeadType() {
			return leadType;
		}
		public void setLeadType(String leadType) {
			this.leadType = leadType;
		}
		public String getGroupCategory() {
			return groupCategory;
		}
		public void setGroupCategory(String groupCategory) {
			this.groupCategory = groupCategory;
		}
		public int getGlobalCustomerId() {
			return globalCustomerId;
		}
		public void setGlobalCustomerId(int globalCustomerId) {
			this.globalCustomerId = globalCustomerId;
		}
		public String getCreatedUtc() {
			return createdUtc;
		}
		public void setCreatedUtc(String createdUtc) {
			this.createdUtc = createdUtc;
		}
		public String getIsHot() {
			return isHot;
		}
		public void setIsHot(String isHot) {
			this.isHot = isHot;
		}
		public String getIsOnShowroom() {
			return isOnShowroom;
		}
		public void setIsOnShowroom(String isOnShowroom) {
			this.isOnShowroom = isOnShowroom;
		}
		public double getPredictionScore() {
			return PredictionScore;
		}
		public void setPredictionScore(double predictionScore) {
			PredictionScore = predictionScore;
		}
	
		
		
}
