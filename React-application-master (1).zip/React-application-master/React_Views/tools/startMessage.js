import colors from 'colors';

/*eslint-disable no-console */

console.log('Starting app in development mode, running tests, linting, and opening default browser at http://localhost:3000...'.green);

