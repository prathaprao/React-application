package com.simpleserver.data.model;

public class DealerResponseTime {

//	int DealerID = 0;
//	int ResponseTime = 0;
//	
//	public int getDealerID() {
//		return DealerID;
//	}
//	public void setDealerID(int dealerID) {
//		DealerID = dealerID;
//	}
//	public int getResponseTime() {
//		return ResponseTime;
//	}
//	public void setResponseTime(int responseTime) {
//		ResponseTime = responseTime;
//	}
	
}
