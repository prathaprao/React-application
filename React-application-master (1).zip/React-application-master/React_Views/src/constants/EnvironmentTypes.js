﻿export const ENV_PROD = 'ENV_PROD';
export const ENV_DEV = 'ENV_DEV';