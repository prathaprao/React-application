import { combineReducers } from 'redux';
import toolbarAppState from './Toolbar';

const rootReducer = combineReducers({
    toolbarAppState
});

export default rootReducer;
